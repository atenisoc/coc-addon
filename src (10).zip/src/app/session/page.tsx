'use client'

import { Suspense } from 'react'
import ChatClient from './ChatClient'
import { useSearchParams } from 'next/navigation'

function PageInner() {
  const params = useSearchParams()
  const scenarioId = params.get('id') || 'unknown'

  const scenarioTitleMap: Record<string, string> = {
    'kisaragi': 'きさらぎ駅',
    'mirror-home': '鏡の奥の家',
    'echoes': '繰り返される命日',
    'demon-mansion': '悪魔の館',
    'hotel-hilbert': 'HOTELヒルベルト',
  }

  const title = scenarioTitleMap[scenarioId] || `探索セッション：${scenarioId}`

  return (
    <main
      className="min-h-screen px-4 py-8 bg-cover bg-center bg-fixed text-white"
      style={{ backgroundImage: "url('/bg/session-dark.jpg')" }}
    >
      <div className="max-w-screen-md mx-auto space-y-6 text-shadow">
        <h1
          className="text-center text-4xl md:text-5xl font-bold tracking-widest text-white"
          style={{
            fontFamily: "'Noto Serif JP', serif",
            textShadow: '2px 2px 4px rgba(0,0,0,0.7)',
          }}
        >
          {title}
        </h1>

        <h2 className="text-center text-sm text-white/60 italic tracking-wide">
          探索セッション（ver. 1.2）
        </h2>

        <ChatClient />
      </div>
    </main>
  )
}

export default function Page() {
  return (
    <Suspense fallback={<div className="text-center text-white">読み込み中…</div>}>
      <PageInner />
    </Suspense>
  )
}
