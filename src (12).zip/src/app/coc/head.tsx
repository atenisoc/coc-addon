export default function Head() {
  return (
    <>
      <link
        href="https://fonts.googleapis.com/css2?family=Zen+Old+Mincho&family=Noto+Serif+JP&display=swap"
        rel="stylesheet"
      />
    </>
  )
}
