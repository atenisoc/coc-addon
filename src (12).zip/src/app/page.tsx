export default function Home() {
  return (
    <main className="p-8 text-white min-h-screen bg-black">
      <h1 className="text-3xl font-bold mb-4">トップページ</h1>
      <p>ここはトップページです。</p>
      <p>きさらぎ駅や他のセッションページへのリンクなどを今後追加予定。</p>
    </main>
  );
}
