// Next.js App Router 用（app ディレクトリ構成）
export async function GET() {
  return new Response('✅ UUID middleware test successful!', { status: 200 })
}
