// /src/components/ChoiceSection.tsx
'use client'
import { useState } from 'react'

export default function ChoiceSection() {
  const [showInput, setShowInput] = useState(false)

  return (
    <div className="space-y-3">
      {/* ボタン等ここに記述 */}
    </div>
  )
}
