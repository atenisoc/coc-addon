import { NextRequest } from 'next/server'
import OpenAI from 'openai'
import { getScenarioDescription } from '@/lib/scenario'

export const runtime = 'edge'

export async function POST(req: NextRequest) {
  const { userInput, history, scenarioId } = await req.json()

  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || '' })
  const scenarioSummary = getScenarioDescription(scenarioId)

  const systemPrompt = `あなたはクトゥルフ神話TRPGのゲームマスターです。
プレイヤーは現在、シナリオ「${scenarioId}」を探索中です。

【シナリオ概要】
${scenarioSummary}

【出力形式】
{
  "reply": "描写本文（最大300字）",
  "options": ["選択肢1", "選択肢2", "選択肢3"]
}

【ルール】
- reply は300字以内で、簡潔かつ情景描写を含めること
- options は必ず3〜4個を返すこと（2個では不十分）
- 選択肢が不足する場合でも、仮選択肢（例：「辺りを見回す」「考えをまとめる」など）を追加して3個にすること
- 各選択肢はシンプルな文字列（例：「駅に入る」「スマホを確認する」など）で構成
- options の各要素は文字列の JSON 配列であること
- options の中に改行やカンマを含めない
- reply や options が欠けた出力は一切許されない

【絶対禁止】
- reply 内に JSON や "options"、"reply" を含むような記述を含めてはならない（構造の誤認を防ぐため）
- 補足説明・コードブロック・HTML・見出しは禁止
- 出力が不完全な場合は空の JSON を返す
`

  try {
    const chatHistory = [
      { role: 'system', content: systemPrompt },
      ...history.map((m: any) => ({
        role: m.role as 'user' | 'assistant',
        content: m.content,
      })),
    ]

    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: chatHistory,
      temperature: 0.8,
    })

    let raw = response.choices[0]?.message.content?.trim() ?? ''

    if (raw.startsWith('```')) {
      raw = raw.replace(/```json|```/g, '').trim()
    }

    const json = JSON.parse(raw)

    let isValid =
      typeof json === 'object' &&
      typeof json.reply === 'string' &&
      !json.reply.includes('"reply"') &&
      !json.reply.includes('"options"') &&
      Array.isArray(json.options) &&
      json.options.every((opt: any) => typeof opt === 'string') &&
      json.options.length >= 3 &&
      json.options.length <= 4

    if (!isValid) {
      console.warn('[構造不正または誤構造検出]', raw)
      return new Response(
        JSON.stringify({
          reply: '※ 正常な応答が得られませんでした（構造不正検出）',
          options: ['様子を見る', '静かに待つ', '誰かを呼ぶ'],
          fallback: true,
          errorFlag: 'structure-invalid'
        }),
        { status: 206 }
      )
    }

    return new Response(JSON.stringify(json), {
      headers: { 'Content-Type': 'application/json' },
      status: 200,
    })
  } catch (err: any) {
    console.error('[OpenAIエラー]', err)
    return new Response(
      JSON.stringify({
        reply: '※ システムエラーが発生しました。現在の状況を確認してください。',
        options: ['様子を見る', '静かに待つ', '誰かを呼ぶ'],
        fallback: true,
        errorFlag: 'exception'
      }),
      { status: 500 }
    )
  }
}
