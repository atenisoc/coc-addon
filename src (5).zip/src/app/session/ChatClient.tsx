'use client'

import { Suspense } from 'react'
import ChatClient from './ChatClient'

export default function Page() {
  return (
    <Suspense fallback={<div className="text-gray-400 text-center mt-8">読み込み中...</div>}>
      <div className="relative w-full max-w-screen-md mx-auto px-4">
        <div className="text-right text-[10px] text-gray-500 mb-1">ver. debug-test-3</div>
        <ChatClient />
      </div>
    </Suspense>
  )
}
