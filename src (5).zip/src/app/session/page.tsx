import ChatClient from './ChatClient'

export default function Page() {
  return (
    <main className="min-h-screen bg-black text-white px-4 py-8">
      <h1 className="text-xl text-center mb-4">デバッグ表示（ver. debug-test-3）</h1>
      <ChatClient />
    </main>
  )
}
