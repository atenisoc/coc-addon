import ChatClient from './ChatClient'

export default function Page() {
  return (
    <main className="min-h-screen bg-black text-white px-4 py-8">
      <ChatClient />
    </main>
  )
}
