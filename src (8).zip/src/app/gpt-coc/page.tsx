export default function Home() {
  return <p>✅ / ページは表示されています</p>
}
