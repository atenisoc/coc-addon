console.log('[API] route.ts 動作確認')
console.log('[OK] 選択肢:', dummyOptions)


// /src/app/api/message/route.ts
export async function POST(req: Request) {
  const { userInput, history } = await req.json()

  const dummyReply = `仮応答：『${userInput}』を受け取りました。探索を続けますか？`

  const dummyOptions = [
    '📖 禁断の書を開く',
    '🕯 銅像の灯りとシンボルを調べる',
    '🚪 左奥のすき間へ進む',
  ]

  return Response.json({
    reply: dummyReply,
    options: dummyOptions,
  })
}

useEffect(() => {
  const forceTest = async () => {
    console.log('[Client] 強制送信テスト発動') // ← 追加ログ
    const res = await fetch('/api/message', {
      method: 'POST',
      body: JSON.stringify({
        userInput: '神社を調べる',
        history: messages,
      }),
    })
    const data = await res.json()
    setMessages([...messages, { role: 'assistant', content: data.reply }])
    setOptions(data.options || [])
    setOptionTrigger((prev) => prev + 1)
  }

  // テスト中は制限を緩くして確実に通す
  if (scenario && showIntro) {
    forceTest()
  }
}, [scenario, showIntro])
