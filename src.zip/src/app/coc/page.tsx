import Chat from '@/components/Chat'

export default function CocPage() {
  return (
    <main>
      <h1 className="text-center text-2xl font-bold my-4">CoC 人狼ゲーム</h1>
      <Chat />
    </main>
  )
}
